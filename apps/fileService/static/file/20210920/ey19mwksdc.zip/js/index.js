// JavaScript Document
$(function(){
	var swiper_banner = new Swiper('.hdk-list .swiper-container', {
		 slidesPerView:2.4,
		 loop:true,
		 initialSlide:2,
		 centeredSlides: true,
	});
	
	$(".hdk-footer .hdk-btn-look").click(function(){
		$(".hdk-mask").fadeIn(100);
		$(".hdk-popup-sel").animate(
			{bottom:'0'},100
		);
	});
	$(".hdk-popup-sel .hdk-cancel").click(function(){
		$(".hdk-mask").fadeOut(100);
		$(this).parent().animate(
			{bottom:'-500'},100
		);
	});
	$(".hdk-mask").click(function(){
		$(".hdk-mask").fadeOut(100);
		$(".hdk-popup-sel").animate(
			{bottom:'-500'},100
		);
	});
	$(".hdk-popup-sel ul li").click(function(){
		$(this).siblings().removeClass("sel");
		$(this).addClass("sel");
		setTimeout(function(){
			$(".hdk-mask").fadeOut(100);
			$(".hdk-popup-sel").animate(
				{bottom:'-500'},100
			);
		},300);
		
	});
});