// JavaScript Document
$(function() {

	//banner
	var swiper_banner = new Swiper('#banner', {
		pagination: {
			el: '#banner .swiper-pagination',
			clickable: true,
		},
	});

	function copyText() {
		var text = document.getElementById("hdk-user-tel").innerText;
		var input = document.getElementById("hdk-user-input");
		input.value = text; // 修改文本框的内容
		input.select(); // 选中文本
		document.execCommand("copy"); // 执行浏览器复制命令
		alert("复制成功");
	}

	$("#hdk-copy").click(function() {
		copyText();
	});

	$(".hdk-footer .hdk-btn-fate").click(function() {
		$(".hdk-mask").fadeIn(100);
		$("#hdk-popup-unlock").fadeIn(100);
	});

	$(".hdk-footer .hdk-btn-love").click(function() {
		$(".hdk-mask").fadeIn(100);
		$("#hdk-popup-success").fadeIn(100);
	});

	$(".hdk-popup .hdk-btn").click(function() {
		$(".hdk-mask").fadeOut(100);
		$(this).parent().fadeOut(100);
	});

	$(".hdk-popup .hdk-close").click(function() {
		$(".hdk-mask").fadeOut(100);
		$(this).parent().fadeOut(100);
	});

	$(".hdk-mask").click(function() {
		$(".hdk-mask").fadeOut(100);
		$(".hdk-popup").fadeOut(100);
	});



});
//视频控制播放
var myVideo = document.getElementById("video1");
var myVideo_btn = document.getElementById("videobtn");
var myVideo_mask = document.getElementById("videomask");
var myVideo_pic = document.getElementById("videopic");

function Pause() {
	myVideo.pause();
	myVideo_btn.className = "hdk-btn";
	myVideo_mask.style.display = "block";
}

function playPause() {
	if (myVideo.paused) {
		myVideo.play();
		myVideo_btn.className = "hdk-btn hdk-btn-stop";
		myVideo_mask.style.display = "none";
		myVideo_pic.style.display = "none";
	} else {
		myVideo.pause();
		myVideo_btn.className = "hdk-btn";
		myVideo_mask.style.display = "block";
	}
	//myVideo.stop();
}

myVideo.addEventListener('ended', function() {
	myVideo_pic.style.display = "block";
	myVideo_btn.className = "hdk-btn";

}, false);

//音频控制播放
var myAudio = document.getElementById("audio1");
var myAudio_btn = document.getElementById("audiobtn");

function audioPlayPause() {
	if (myAudio.paused) {
		myAudio.play();
		myAudio_btn.className = "hdk-btn-stop";
	} else {
		myAudio.pause();
		myAudio_btn.className = "";
	}
}

myAudio.addEventListener('ended', function() {
	myAudio_btn.className = "btn";
}, false);

//获取总时长
var _audio = document.getElementById("audio1");

//默认的时候让所有的音频加载，否则在火狐ie等浏览器下由于jquery插件的存在导致onloadedmetadata事件不响应
_audio.load();

//音频加载完成后的一系列操作
function duration(){
    // if( _ReviewsBox.hasClass('homework-audio-loading') ){
    //     return false;
    // }
    var time = _audio.duration;
        //分钟
    var minute = time / 60;
    var minutes = parseInt(minute);
    if (minutes < 10) {
        minutes = "0" + minutes;
    }
    //秒
    var second = time % 60;
    var seconds = Math.round(second);
    if (seconds < 10) {
        seconds = "0" + seconds;
    }

    //总共时长的秒数
    var allTime = parseInt(minutes*60 + seconds);
	document.getElementById('audiotime').innerHTML=allTime+"秒";
}

_audio.onloadedmetadata = duration;
